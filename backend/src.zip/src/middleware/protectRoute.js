import { requireAuth } from "@clerk/express";
import User from "../models/User.js";

export const protectRoute = [
  requireAuth(),

  async (req, res, next) => {
    try {
      // ✅ Clerk se authenticated user ka ID
      const clerkId = req.auth.userId;

      if (!clerkId) {
        return res
          .status(401)
          .json({ message: "Unauthorized - invalid token" });
      }

      // ✅ DB me user find karo
      const user = await User.findOne({ clerkId });

      if (!user) {
        return res
          .status(404)
          .json({ message: "User not found in database" });
      }

      // ✅ req.user attach karo (important for controllers)
      req.user = user;

      next();
    } catch (error) {
      console.error("❌ Error in protectRoute middleware:", error);

      res.status(500).json({
        message: "Internal Server Error",
      });
    }
  },
];